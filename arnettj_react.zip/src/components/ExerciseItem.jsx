import '../App.css';
import { MdOutlineUpdate, MdDelete } from "react-icons/md";


function ExerciseItem({ exercise, onDelete, onEdit }) {

    return (
        <tr className="collection-item">
            <td>{exercise.name}</td>
            <td>{exercise.reps}</td>
            <td>{exercise.weight}</td>
            <td>{exercise.unit}</td>
            <td>{exercise.date}</td>
            <td>
                <MdOutlineUpdate size={20} onClick={e => {e.preventDefault(); onEdit(exercise)}}>Edit</MdOutlineUpdate>
            </td>
            <td>
                <MdDelete size={20} onClick={e => {e.preventDefault(); onDelete(exercise._id)}}>Delete </MdDelete>
            </td>
        </tr>
    );
}

export default ExerciseItem;