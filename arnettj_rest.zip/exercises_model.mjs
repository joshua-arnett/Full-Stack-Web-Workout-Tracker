import mongoose from 'mongoose';
import 'dotenv/config';


const EXERCISE_CLASS = "Exercise";

let connection = undefined;
let Exercise = undefined;

async function connect() {
    try{
        await mongoose.connect(process.env.MONGODB_CONNECT_STRING);
        connection = mongoose.connection;
        console.log("Successfully connected to MongoDB using Mongoose!");
        Exercise = createModel();
    } catch(err){
        console.log(err);
        throw Error(`Could not connect to MongoDB ${err.message}`);
    };
}

function createModel(){
    // Define schema
    const exerciseSchema = mongoose.Schema({
        name: {type: String, required: true},
        reps: {type: Number, required: true},
        weight: {type: Number, required: true},
        unit: {type: String, required: true},
        date: {type: String, required: true},
    });

    // We compile the model class from the schema
    return mongoose.model(EXERCISE_CLASS, exerciseSchema);
}

const createExercise = async (name, reps, weight, unit, date) => {
    if(name.length > 0 && reps > 0 && weight > 0 && (unit == "kgs" || unit === "lbs") && isDateValid(date)){
        const exercise = new Exercise({name: name, reps: reps, weight: weight, unit: unit, date: date});
        return exercise.save();
    } else{
        return null
    }
}

/**
*
* @param {string} date
* Return true if the date format is MM-DD-YY where MM, DD and YY are 2 digit integers
*/
function isDateValid(date) {
    // Test using a regular expression. 
    // To learn about regular expressions see Chapter 6 of the text book
    const format = /^\d\d-\d\d-\d\d$/;
    return format.test(date);
}

async function findExercises(filter) {
    return await Exercise.find(filter).exec();
}

async function findExercisesById(_id) {
    return await Exercise.findById(_id).exec();
}

async function replaceExercise(_id, filter) {
    const { name, reps, weight, unit, date } = filter
    if(name.length > 0 && reps > 0 && weight > 0 && (unit == "kgs" || unit === "lbs") && isDateValid(date)){
        const result = await Exercise.replaceOne({"_id": _id},
        {name: name, reps: reps, weight: weight, unit: unit, date: date});
        return result.modifiedCount;
    } else{
        return null;
    }
}

async function deleteById(_id) {
    const result = await Exercise.deleteOne({"_id": _id});
    return result.deletedCount;
}

export { connect, createExercise, findExercises, findExercisesById, replaceExercise, deleteById };
